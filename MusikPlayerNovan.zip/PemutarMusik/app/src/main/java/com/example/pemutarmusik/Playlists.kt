package com.example.pemutarmusik

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Daftar putar disimpan sebagai JSON sederhana. "Favorit" adalah daftar bawaan. */
object Playlists {
    const val FAV = "Favorit"

    private fun sp(c: Context) = c.getSharedPreferences("playlists", Context.MODE_PRIVATE)

    private fun load(c: Context): LinkedHashMap<String, MutableList<Long>> {
        val m = LinkedHashMap<String, MutableList<Long>>()
        val raw = sp(c).getString("data", null)
        if (raw != null) {
            try {
                val o = JSONObject(raw)
                val keys = o.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val a = o.getJSONArray(k)
                    val l = ArrayList<Long>()
                    for (i in 0 until a.length()) l.add(a.getLong(i))
                    m[k] = l
                }
            } catch (_: Exception) {
            }
        }
        return m
    }

    private fun save(c: Context, m: Map<String, List<Long>>) {
        val o = JSONObject()
        for ((k, v) in m) {
            val a = JSONArray()
            for (id in v) a.put(id)
            o.put(k, a)
        }
        sp(c).edit().putString("data", o.toString()).apply()
    }

    /** Nama daftar putar buatan pengguna (tanpa Favorit). */
    fun names(c: Context): List<String> = load(c).keys.filter { it != FAV }

    fun ids(c: Context, name: String): List<Long> = load(c)[name] ?: emptyList()

    fun create(c: Context, name: String): Boolean {
        val n = name.trim()
        if (n.isEmpty() || n.equals(FAV, ignoreCase = true)) return false
        val m = load(c)
        if (m.keys.any { it.equals(n, ignoreCase = true) }) return false
        m[n] = ArrayList()
        save(c, m)
        return true
    }

    fun delete(c: Context, name: String) {
        val m = load(c)
        if (m.remove(name) != null) save(c, m)
    }

    fun rename(c: Context, old: String, new: String): Boolean {
        val n = new.trim()
        if (n.isEmpty() || n.equals(FAV, ignoreCase = true)) return false
        val m = load(c)
        if (!m.containsKey(old)) return false
        if (!old.equals(n, ignoreCase = true) && m.keys.any { it.equals(n, ignoreCase = true) }) return false
        val out = LinkedHashMap<String, MutableList<Long>>()
        for ((k, v) in m) out[if (k == old) n else k] = v
        save(c, out)
        return true
    }

    fun add(c: Context, name: String, newIds: List<Long>) {
        val m = load(c)
        val l = m.getOrPut(name) { ArrayList() }
        for (id in newIds) if (!l.contains(id)) l.add(id)
        save(c, m)
    }

    fun remove(c: Context, name: String, id: Long) {
        val m = load(c)
        m[name]?.remove(id)
        save(c, m)
    }

    fun isFav(c: Context, id: Long): Boolean = ids(c, FAV).contains(id)

    /** Mengembalikan status favorit yang baru. */
    fun toggleFav(c: Context, id: Long): Boolean {
        return if (isFav(c, id)) {
            remove(c, FAV, id)
            false
        } else {
            add(c, FAV, listOf(id))
            true
        }
    }
}
