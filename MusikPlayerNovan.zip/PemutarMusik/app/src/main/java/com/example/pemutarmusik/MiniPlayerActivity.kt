package com.example.pemutarmusik

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

/**
 * Mini player: jendela kecil untuk memutar file audio yang dibuka dari file manager,
 * tanpa membuka aplikasi lengkap. Musik tetap berjalan di latar belakang setelah ditutup.
 */
class MiniPlayerActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var pending: Uri? = null
    private var touching = false
    private var lastPct = -1
    private var lastSpoken = ""

    private lateinit var tvName: TextView
    private lateinit var seek: SeekBar
    private lateinit var cur: TextView
    private lateinit var dur: TextView
    private lateinit var play: ImageButton
    private lateinit var rew: Button
    private lateinit var ff: Button

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = updateUi()
    }

    private val ticker = object : Runnable {
        override fun run() {
            val c = controller
            if (c != null && !touching) {
                val d = c.duration
                val pos = c.currentPosition
                if (d != C.TIME_UNSET && d > 0) {
                    seek.max = d.toInt()
                    seek.progress = pos.toInt()
                    val sp = "${Util.percent(pos, d)} persen, ${Util.spoken(pos / 5000 * 5000)} dari ${Util.spoken(d)}"
                    if (sp != lastSpoken) {
                        lastSpoken = sp
                        ViewCompat.setStateDescription(seek, sp)
                    }
                }
                cur.text = Util.fmt(pos)
                dur.text = if (d == C.TIME_UNSET) "0:00" else Util.fmt(d)
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mini)
        setTitle("Musik Player Novan")
        tvName = findViewById(R.id.miniTitle)
        seek = findViewById(R.id.miniSeek)
        cur = findViewById(R.id.miniCur)
        dur = findViewById(R.id.miniDur)
        play = findViewById(R.id.miniPlay)
        rew = findViewById(R.id.miniRew)
        ff = findViewById(R.id.miniFf)

        play.setOnClickListener {
            val c = controller ?: return@setOnClickListener
            if (c.isPlaying) c.pause() else {
                if (c.mediaItemCount == 0) return@setOnClickListener
                if (c.playbackState == Player.STATE_ENDED) c.seekToDefaultPosition()
                c.play()
            }
        }
        rew.setOnClickListener { seekBy(-Prefs.seekStepMs(this), true) }
        ff.setOnClickListener { seekBy(Prefs.seekStepMs(this), true) }
        findViewById<View>(R.id.miniOpen).setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            finish()
        }
        findViewById<View>(R.id.miniClose).setOnClickListener { finish() }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                cur.text = Util.fmt(p.toLong())
                if (!touching) controller?.seekTo(p.toLong())
                else {
                    val pct = Util.percent(p.toLong(), s.max.toLong())
                    if (pct != lastPct) {
                        lastPct = pct
                        s.announceForAccessibility("$pct persen")
                    }
                }
            }

            override fun onStartTrackingTouch(s: SeekBar) {
                touching = true
                lastPct = -1
            }

            override fun onStopTrackingTouch(s: SeekBar) {
                controller?.seekTo(s.progress.toLong())
                touching = false
                lastSpoken = ""
                s.announceForAccessibility("${Util.percent(s.progress.toLong(), s.max.toLong())} persen")
            }
        })
        ViewCompat.setAccessibilityDelegate(seek, object : AccessibilityDelegateCompat() {
            override fun performAccessibilityAction(host: View, action: Int, args: Bundle?): Boolean =
                when (action) {
                    AccessibilityNodeInfo.ACTION_SCROLL_FORWARD -> {
                        seekBy(Prefs.seekStepMs(this@MiniPlayerActivity), true); true
                    }
                    AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD -> {
                        seekBy(-Prefs.seekStepMs(this@MiniPlayerActivity), true); true
                    }
                    else -> super.performAccessibilityAction(host, action, args)
                }
        })

        takeIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        takeIntent(intent)
    }

    private fun takeIntent(i: Intent?) {
        if (i?.action != Intent.ACTION_VIEW) return
        pending = i.data
        i.action = Intent.ACTION_MAIN
        playPending()
    }

    private fun playPending() {
        val uri = pending ?: return
        val c = controller ?: return
        pending = null
        c.setMediaItem(Util.externalItem(this, uri), 0L)
        c.prepare()
        c.play()
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            try {
                controller = f.get().also { it.addListener(listener) }
                playPending()
                updateUi()
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(this))
        handler.post(ticker)
    }

    override fun onStop() {
        handler.removeCallbacks(ticker)
        controller?.removeListener(listener)
        controller = null
        future?.let { MediaController.releaseFuture(it) }
        future = null
        super.onStop()
    }

    private fun seekBy(delta: Long, announce: Boolean) {
        val c = controller ?: return
        val d = c.duration
        if (d == C.TIME_UNSET || d <= 0) return
        val np = (c.currentPosition + delta).coerceIn(0L, maxOf(0L, d - 500))
        c.seekTo(np)
        seek.progress = np.toInt()
        cur.text = Util.fmt(np)
        val pct = Util.percent(np, d)
        lastSpoken = "$pct persen, ${Util.spoken(np)} dari ${Util.spoken(d)}"
        ViewCompat.setStateDescription(seek, lastSpoken)
        if (announce) seek.announceForAccessibility("$pct persen, ${Util.spoken(np)}")
    }

    private fun updateUi() {
        val step = (Prefs.seekStepMs(this) / 1000).toInt()
        rew.text = "Mundur $step detik"
        ff.text = "Maju $step detik"
        val c = controller ?: return
        val t = c.mediaMetadata.title?.toString()
        tvName.text = t ?: "Belum ada lagu diputar"
        tvName.contentDescription = if (t == null) "Belum ada lagu diputar" else "Sedang diputar: $t"
        play.setImageResource(if (c.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
        play.contentDescription = if (c.isPlaying) "Jeda" else "Putar"
    }
}
