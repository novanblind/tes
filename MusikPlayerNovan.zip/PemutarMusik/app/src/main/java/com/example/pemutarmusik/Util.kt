package com.example.pemutarmusik

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

object Util {
    fun spoken(ms: Long): String {
        if (ms < 0) return "0 detik"
        val s = ms / 1000
        val m = s / 60
        val r = s % 60
        return if (m > 0) "$m menit $r detik" else "$r detik"
    }

    fun fmt(ms: Long): String {
        if (ms < 0) return "0:00"
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    /** Persen posisi lagu (0-100). */
    fun percent(pos: Long, dur: Long): Int =
        if (dur <= 0L) 0 else (pos * 100L / dur).toInt().coerceIn(0, 100)

    /** Item media dari file yang dibuka dari luar (file manager). mediaId bukan angka. */
    fun externalItem(ctx: Context, uri: Uri): MediaItem {
        var name: String? = null
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) name = it.getString(0) }
        } catch (_: Exception) {
        }
        val title = (name ?: uri.lastPathSegment ?: "Audio").substringBeforeLast('.')
        return MediaItem.Builder()
            .setMediaId("ext:$uri")
            .setUri(uri)
            .setMediaMetadata(MediaMetadata.Builder().setTitle(title).build())
            .build()
    }
}
