package com.example.pemutarmusik

import android.app.PendingIntent
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Layanan pemutar latar belakang.
 *
 * Perpindahan lagu dibuat menyatu:
 *  - Gapless: ExoPlayer menyambung lagu berikutnya tanpa jeda.
 *  - Crossfade: ujung lagu lama memudar sambil lagu baru menguat. Berlaku untuk pergantian
 *    otomatis maupun saat tombol berikutnya/sebelumnya ditekan (bisa diatur).
 */
class PlaybackService : MediaSessionService() {

    companion object {
        @Volatile
        var instance: PlaybackService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var exo: ExoPlayer
    private var session: MediaSession? = null
    private lateinit var prefs: SharedPreferences
    private lateinit var state: SharedPreferences

    private val attrs = AudioAttributes.Builder()
        .setUsage(C.USAGE_MEDIA)
        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
        .build()

    // crossfade
    private var outgoing: ExoPlayer? = null     // pemain yang memudarkan lagu lama
    private var prewarmed: ExoPlayer? = null    // pemain lagu saat ini yang disiapkan lebih dulu
    private var prewarmedId: String? = null
    private var fading = false
    private var fadeStart = 0L
    private var fadeMs = 1L

    // timer tidur
    private var sleepEnd = 0L

    // ulang A-B
    var abA = -1L
        private set
    var abB = -1L
        private set

    private var lastSave = 0L

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            Prefs.AUDIO_FOCUS -> exo.setAudioAttributes(attrs, prefs.getBoolean(Prefs.AUDIO_FOCUS, true))
            Prefs.SKIP_SILENCE -> exo.setSkipSilenceEnabled(prefs.getBoolean(Prefs.SKIP_SILENCE, false))
            Prefs.PAUSE_UNPLUG -> exo.setHandleAudioBecomingNoisy(prefs.getBoolean(Prefs.PAUSE_UNPLUG, true))
            else -> {}
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            try {
                tick()
            } catch (_: Throwable) {
            }
            val delay = when {
                fading -> 40L
                abB > 0 -> 80L
                else -> 250L
            }
            handler.postDelayed(this, delay)
        }
    }

    private val sleepRunnable = Runnable {
        exo.pause()
        sleepEnd = 0L
    }

    // ---------------------------------------------------------------- siklus hidup

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = Prefs.of(this)
        state = Prefs.state(this)

        exo = ExoPlayer.Builder(this)
            .setAudioAttributes(attrs, prefs.getBoolean(Prefs.AUDIO_FOCUS, true)) // fokus audio (bisa dimatikan di Pengaturan)
            .setHandleAudioBecomingNoisy(prefs.getBoolean(Prefs.PAUSE_UNPLUG, true))
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()

        // Sesi audio sendiri agar efek (equalizer dll.) berlaku juga di pemain crossfade
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val sid = am.generateAudioSessionId()
        if (sid != AudioManager.ERROR) exo.setAudioSessionId(sid)
        AudioFx.attach(this, exo.audioSessionId)

        exo.repeatMode = state.getInt("repeat", Player.REPEAT_MODE_OFF)
        exo.shuffleModeEnabled = state.getBoolean("shuffle", false)
        exo.setPlaybackSpeed(state.getFloat("speed", 1f))
        exo.setSkipSilenceEnabled(prefs.getBoolean(Prefs.SKIP_SILENCE, false))

        exo.addListener(object : Player.Listener {
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (!playWhenReady) {
                    if (fading) endFade()
                    saveState()
                    if (reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM) {
                        exo.setPauseAtEndOfMediaItems(false)
                    }
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                abA = -1L
                abB = -1L
                val id = prewarmedId
                if (id != null && id != mediaItem?.mediaId) dropPrewarm()
                saveState()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    endFade()
                    saveState()
                }
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                state.edit().putInt("repeat", repeatMode).apply()
            }

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                state.edit().putBoolean("shuffle", shuffleModeEnabled).apply()
            }

            override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
                state.edit().putFloat("speed", playbackParameters.speed).apply()
            }
        })

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        session = MediaSession.Builder(this, Fwd(exo)).setSessionActivity(open).build()

        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        handler.post(ticker)
        restoreQueue()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (!exo.playWhenReady || exo.mediaItemCount == 0) {
            saveState()
            stopSelf()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { saveState() } catch (_: Throwable) {}
        endFade()
        dropPrewarm()
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        AudioFx.release()
        session?.run {
            release()
        }
        session = null
        exo.release()
        instance = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- pemain pembungkus

    /** Menyisipkan crossfade pada perpindahan lagu manual (tombol, notifikasi, antrean). */
    private inner class Fwd(p: ExoPlayer) : ForwardingPlayer(p) {

        override fun seekToNext() {
            if (exo.hasNextMediaItem()) changeItem { exo.seekToNextMediaItem() } else exo.seekToNext()
        }

        override fun seekToNextMediaItem() {
            if (exo.hasNextMediaItem()) changeItem { exo.seekToNextMediaItem() } else exo.seekToNextMediaItem()
        }

        override fun seekToPrevious() {
            val restart = prefs.getBoolean(Prefs.PREV_RESTART, true)
            if ((restart && exo.currentPosition > 3000L) || !exo.hasPreviousMediaItem()) {
                exo.seekTo(0L)
            } else {
                changeItem { exo.seekToPreviousMediaItem() }
            }
        }

        override fun seekToPreviousMediaItem() {
            if (exo.hasPreviousMediaItem()) changeItem { exo.seekToPreviousMediaItem() } else exo.seekTo(0L)
        }

        override fun seekTo(mediaItemIndex: Int, positionMs: Long) {
            if (mediaItemIndex != exo.currentMediaItemIndex) {
                changeItem { exo.seekTo(mediaItemIndex, positionMs) }
            } else {
                exo.seekTo(mediaItemIndex, positionMs)
            }
        }

        override fun seekToDefaultPosition(mediaItemIndex: Int) {
            if (mediaItemIndex != exo.currentMediaItemIndex) {
                changeItem { exo.seekToDefaultPosition(mediaItemIndex) }
            } else {
                exo.seekToDefaultPosition(mediaItemIndex)
            }
        }
    }

    // ---------------------------------------------------------------- crossfade

    private fun canManualFade(): Boolean =
        prefs.getBoolean(Prefs.CROSSFADE_MANUAL, true) &&
            Prefs.crossfadeSec(this) > 0 &&
            exo.isPlaying &&
            exo.currentMediaItem != null

    private fun changeItem(block: () -> Unit) {
        if (!canManualFade()) {
            block()
            return
        }
        endFade()
        val total = min(Prefs.crossfadeSec(this) * 1000L, 3000L)
        beginFade(total)
        block()
    }

    private fun newOutgoing(item: MediaItem, posMs: Long): ExoPlayer {
        val q = ExoPlayer.Builder(this).build()
        q.setAudioSessionId(exo.audioSessionId)
        q.playbackParameters = exo.playbackParameters
        q.setMediaItem(item)
        q.prepare()
        q.seekTo(posMs)
        q.playWhenReady = false
        return q
    }

    private fun dropPrewarm() {
        try { prewarmed?.release() } catch (_: Throwable) {}
        prewarmed = null
        prewarmedId = null
    }

    /** Menyiapkan salinan lagu saat ini agar siap dipakai saat crossfade dimulai. */
    private fun prewarm(item: MediaItem, startAt: Long) {
        dropPrewarm()
        prewarmed = newOutgoing(item, startAt)
        prewarmedId = item.mediaId
    }

    /** Mulai memudarkan lagu saat ini di pemain kedua; pemain utama diturunkan ke volume 0. */
    private fun beginFade(ms: Long) {
        val item = exo.currentMediaItem ?: return
        val ready = prewarmed?.takeIf { prewarmedId == item.mediaId }
        if (ready == null) {
            dropPrewarm()
        } else {
            prewarmed = null
            prewarmedId = null
        }
        val pos = exo.currentPosition
        val out = ready ?: newOutgoing(item, pos)
        out.seekTo(pos)
        out.volume = 1f
        out.playWhenReady = true
        outgoing = out
        exo.volume = 0f
        fadeMs = if (ms < 1L) 1L else ms
        fadeStart = SystemClock.uptimeMillis()
        fading = true
    }

    private fun tickFade() {
        val q = outgoing
        if (q == null) {
            endFade()
            return
        }
        val t = ((SystemClock.uptimeMillis() - fadeStart).toFloat() / fadeMs).coerceIn(0f, 1f)
        exo.volume = sin(t * PI / 2).toFloat()
        q.volume = cos(t * PI / 2).toFloat()
        if (t >= 1f) endFade()
    }

    private fun endFade() {
        try { outgoing?.release() } catch (_: Throwable) {}
        outgoing = null
        fading = false
        if (this::exo.isInitialized) exo.volume = 1f
    }

    private fun autoCrossfade() {
        val sec = Prefs.crossfadeSec(this)
        if (sec <= 0 || fading) return
        if (exo.getPauseAtEndOfMediaItems()) return
        if (exo.repeatMode == Player.REPEAT_MODE_ONE) return
        if (abA >= 0) return
        if (!exo.hasNextMediaItem()) return
        val item = exo.currentMediaItem ?: return
        val dur = exo.duration
        if (dur == C.TIME_UNSET || dur <= 0L) return
        val total = min(sec * 1000L, dur / 3)
        val remain = dur - exo.currentPosition
        if (remain <= total) {
            beginFade(total)
            if (fading) exo.seekToNextMediaItem()
        } else if (remain <= total + 3000L && prewarmedId != item.mediaId) {
            prewarm(item, (dur - total).coerceAtLeast(0L))
        }
    }

    // ---------------------------------------------------------------- detak berkala

    private fun tick() {
        if (fading) tickFade()
        if (abA >= 0 && abB > abA && exo.currentPosition >= abB) exo.seekTo(abA)
        if (exo.isPlaying) {
            autoCrossfade()
            val now = SystemClock.elapsedRealtime()
            if (now - lastSave > 5000L) {
                lastSave = now
                savePosition()
            }
        }
    }

    // ---------------------------------------------------------------- timer tidur

    fun startSleep(minutes: Int) {
        cancelSleep()
        val ms = minutes * 60_000L
        sleepEnd = SystemClock.elapsedRealtime() + ms
        handler.postDelayed(sleepRunnable, ms)
    }

    fun sleepAfterTrack() {
        cancelSleep()
        exo.setPauseAtEndOfMediaItems(true)
    }

    fun cancelSleep() {
        handler.removeCallbacks(sleepRunnable)
        sleepEnd = 0L
        exo.setPauseAtEndOfMediaItems(false)
    }

    fun sleepRemainingMs(): Long =
        if (sleepEnd > 0L) maxOf(0L, sleepEnd - SystemClock.elapsedRealtime()) else 0L

    fun isSleepAfterTrack(): Boolean = exo.getPauseAtEndOfMediaItems()

    // ---------------------------------------------------------------- ulang A-B

    fun markA(): Long {
        abA = exo.currentPosition
        abB = -1L
        return abA
    }

    fun markB(): Boolean {
        if (abA < 0) return false
        val p = exo.currentPosition
        if (p <= abA + 500L) return false
        abB = p
        exo.seekTo(abA)
        return true
    }

    fun clearAB() {
        abA = -1L
        abB = -1L
    }

    // ---------------------------------------------------------------- simpan & pulihkan

    private fun saveState() {
        if (!prefs.getBoolean(Prefs.REMEMBER_QUEUE, true)) return
        val n = exo.mediaItemCount
        if (n == 0) return
        // File yang dibuka dari luar (bukan dari pustaka) tidak disimpan
        for (i in 0 until n) if (exo.getMediaItemAt(i).mediaId.toLongOrNull() == null) return
        val sb = StringBuilder()
        for (i in 0 until n) {
            if (i > 0) sb.append(',')
            sb.append(exo.getMediaItemAt(i).mediaId)
        }
        state.edit()
            .putString("ids", sb.toString())
            .putInt("index", exo.currentMediaItemIndex)
            .putLong("pos", exo.currentPosition)
            .apply()
    }

    private fun savePosition() {
        if (!prefs.getBoolean(Prefs.REMEMBER_QUEUE, true) || exo.mediaItemCount == 0) return
        if (exo.currentMediaItem?.mediaId?.toLongOrNull() == null) return
        state.edit()
            .putInt("index", exo.currentMediaItemIndex)
            .putLong("pos", exo.currentPosition)
            .apply()
    }

    /** Memulihkan antrean terakhir dalam keadaan jeda. */
    private fun restoreQueue() {
        if (!prefs.getBoolean(Prefs.REMEMBER_QUEUE, true)) return
        val ids = state.getString("ids", null)
            ?.split(',')
            ?.mapNotNull { it.toLongOrNull() }
            ?: return
        if (ids.isEmpty()) return
        val index = state.getInt("index", 0)
        val pos = state.getLong("pos", 0L)
        Thread {
            val byId = Library.load(this).associateBy { it.id }
            val items = ids.mapNotNull { byId[it]?.toMediaItem() }
            handler.post {
                if (instance === this && exo.mediaItemCount == 0 && items.isNotEmpty()) {
                    val curId = ids.getOrNull(index)?.toString()
                    val start = items.indexOfFirst { it.mediaId == curId }.coerceAtLeast(0)
                    exo.setMediaItems(items, start, if (start == index) pos else 0L)
                    exo.prepare()
                }
            }
        }.start()
    }
}
