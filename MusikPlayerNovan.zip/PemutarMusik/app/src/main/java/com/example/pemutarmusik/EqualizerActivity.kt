package com.example.pemutarmusik

import android.content.ComponentName
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.Locale

/**
 * Equalizer dan efek suara. Semua penggeser memakai 20 langkah supaya setiap usapan
 * pembaca layar menggeser tepat satu langkah.
 */
class EqualizerActivity : AppCompatActivity() {

    private companion object {
        const val STEPS = 20
        const val LOUD_STEPS = 15
    }

    private lateinit var box: LinearLayout
    private var future: ListenableFuture<MediaController>? = null
    private var guard = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Equalizer dan efek suara"
        val scroll = ScrollView(this)
        scroll.fitsSystemWindows = true
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(16), dp(16), dp(32))
        scroll.addView(box)
        setContentView(scroll)
        heading("Equalizer dan efek suara")
        text("Menyiapkan efek suara...")
    }

    override fun onStart() {
        super.onStart()
        // Menyambung ke layanan agar efek audio tersedia selama layar ini terbuka
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            try {
                f.get()
            } catch (_: Exception) {
            }
            build()
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        future?.let { MediaController.releaseFuture(it) }
        future = null
        super.onStop()
    }

    // ---------------------------------------------------------------- tampilan

    private fun build() {
        box.removeAllViews()
        heading("Equalizer dan efek suara")
        if (!AudioFx.available) {
            text("Perangkat ini tidak mendukung efek suara, atau pemutar belum siap. " +
                "Putar satu lagu lalu buka layar ini lagi.")
            return
        }
        val p = Prefs.of(this)

        val sw = SwitchCompat(this)
        sw.text = "Aktifkan efek suara"
        sw.textSize = 18f
        sw.minHeight = dp(56)
        sw.isChecked = p.getBoolean(AudioFx.K_ON, false)
        sw.setOnCheckedChangeListener { _, on ->
            if (!guard) {
                p.edit().putBoolean(AudioFx.K_ON, on).apply()
                AudioFx.apply(this)
            }
        }
        box.addView(sw)

        val ensureOn = {
            if (!sw.isChecked) {
                guard = true
                sw.isChecked = true
                guard = false
                p.edit().putBoolean(AudioFx.K_ON, true).apply()
            }
        }

        if (AudioFx.hasEq) {
            val preset = p.getInt(AudioFx.K_PRESET, -1)
            val presetName = AudioFx.presets.getOrNull(preset) ?: "Kustom"
            val btn = Button(this)
            btn.text = "Preset: $presetName"
            btn.textSize = 16f
            btn.minHeight = dp(56)
            btn.contentDescription = "Pilih preset equalizer. Sekarang: $presetName"
            btn.setOnClickListener {
                val labels = (AudioFx.presets + "Kustom (atur sendiri)").toTypedArray()
                AlertDialog.Builder(this).setTitle("Preset equalizer").setItems(labels) { _, w ->
                    if (w < AudioFx.presets.size) {
                        ensureOn()
                        AudioFx.selectPreset(this, w)
                        AudioFx.apply(this)
                    } else {
                        p.edit().putInt(AudioFx.K_PRESET, -1).apply()
                        AudioFx.apply(this)
                    }
                    build()
                }.show()
            }
            box.addView(btn)

            heading("Pita frekuensi")
            val lv = AudioFx.levels(this)
            val range = (AudioFx.maxLevel - AudioFx.minLevel).coerceAtLeast(1)
            for (i in 0 until AudioFx.bandCount) {
                val name = hzLabel(AudioFx.centerHz[i])
                val start = ((lv[i] - AudioFx.minLevel) * STEPS + range / 2) / range
                slider(
                    name, STEPS, start.coerceIn(0, STEPS),
                    { pr -> db(AudioFx.minLevel + pr * range / STEPS) },
                    { pr -> spokenDb(AudioFx.minLevel + pr * range / STEPS) }
                ) { pr ->
                    ensureOn()
                    AudioFx.setBand(this, i, AudioFx.minLevel + pr * range / STEPS)
                }
            }
        }

        if (AudioFx.hasBass) {
            heading("Bass")
            slider(
                "Penguat bass", STEPS, p.getInt(AudioFx.K_BASS, 0) * STEPS / 1000,
                { pr -> "${pr * 5} persen" }, { pr -> "${pr * 5} persen" }
            ) { pr ->
                ensureOn()
                p.edit().putInt(AudioFx.K_BASS, pr * 50).apply()
                AudioFx.apply(this)
            }
        }

        if (AudioFx.hasVirt) {
            slider(
                "Virtualizer (suara lebih lebar)", STEPS, p.getInt(AudioFx.K_VIRT, 0) * STEPS / 1000,
                { pr -> "${pr * 5} persen" }, { pr -> "${pr * 5} persen" }
            ) { pr ->
                ensureOn()
                p.edit().putInt(AudioFx.K_VIRT, pr * 50).apply()
                AudioFx.apply(this)
            }
        }

        if (AudioFx.hasLoud) {
            slider(
                "Penguat volume", LOUD_STEPS, p.getInt(AudioFx.K_LOUD, 0) / 100,
                { pr -> "tambah $pr dB" }, { pr -> "tambah $pr desibel" }
            ) { pr ->
                ensureOn()
                p.edit().putInt(AudioFx.K_LOUD, pr * 100).apply()
                AudioFx.apply(this)
            }
        }

        val reset = Button(this)
        reset.text = "Atur ulang semua efek"
        reset.textSize = 16f
        reset.minHeight = dp(56)
        reset.setOnClickListener {
            AudioFx.resetAll(this)
            build()
        }
        box.addView(reset)
    }

    private fun slider(
        name: String,
        max: Int,
        start: Int,
        valueText: (Int) -> String,
        spokenText: (Int) -> String,
        onChange: (Int) -> Unit
    ) {
        val label = TextView(this)
        label.textSize = 16f
        label.setPadding(0, dp(12), 0, 0)
        label.text = "$name: ${valueText(start)}"
        label.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO

        val sb = SeekBar(this)
        sb.max = max
        sb.progress = start
        sb.minimumHeight = dp(48)
        sb.contentDescription = name
        ViewCompat.setStateDescription(sb, spokenText(start))
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                label.text = "$name: ${valueText(p)}"
                ViewCompat.setStateDescription(s, spokenText(p))
                if (fromUser) onChange(p)
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        box.addView(label)
        box.addView(sb)
    }

    private fun heading(s: String) {
        val t = TextView(this)
        t.text = s
        t.textSize = 22f
        t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        t.setPadding(0, dp(16), 0, dp(4))
        ViewCompat.setAccessibilityHeading(t, true)
        box.addView(t)
    }

    private fun text(s: String) {
        val t = TextView(this)
        t.text = s
        t.textSize = 16f
        box.addView(t)
    }

    // ---------------------------------------------------------------- pembantu

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun hzLabel(hz: Int): String =
        if (hz >= 1000) String.format(Locale("id"), "%.1f kHz", hz / 1000f) else "$hz Hz"

    private fun db(mb: Int): String = String.format(Locale("id"), "%+.1f dB", mb / 100f)

    private fun spokenDb(mb: Int): String {
        val v = String.format(Locale("id"), "%.1f", Math.abs(mb) / 100f)
        return when {
            mb > 0 -> "naik $v desibel"
            mb < 0 -> "turun $v desibel"
            else -> "datar, 0 desibel"
        }
    }
}
