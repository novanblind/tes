package com.example.pemutarmusik

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatDelegate
import androidx.preference.PreferenceManager

/** Kunci dan pembantu untuk pengaturan aplikasi. */
object Prefs {
    const val CROSSFADE = "crossfade"              // detik; "0" = gapless (tanpa jeda)
    const val CROSSFADE_MANUAL = "crossfade_manual"
    const val SKIP_SILENCE = "skip_silence"
    const val PREV_RESTART = "prev_restart"
    const val PAUSE_UNPLUG = "pause_unplug"
    const val REMEMBER_QUEUE = "remember_queue"
    const val ANNOUNCE = "announce_track"
    const val AUDIO_FOCUS = "audio_focus"
    const val SEEK_STEP = "seek_step"
    const val THEME = "theme"
    const val SORT = "sort"
    const val MIN_DURATION = "min_duration"

    /** Pengaturan yang diubah lewat layar Pengaturan. */
    fun of(c: Context): SharedPreferences = PreferenceManager.getDefaultSharedPreferences(c)

    /** Status pemutar (antrean terakhir, mode ulang/acak, kecepatan). */
    fun state(c: Context): SharedPreferences = c.getSharedPreferences("state", Context.MODE_PRIVATE)

    fun crossfadeSec(c: Context): Int = of(c).getString(CROSSFADE, "3")?.toIntOrNull() ?: 3

    fun seekStepMs(c: Context): Long =
        (of(c).getString(SEEK_STEP, "10")?.toLongOrNull() ?: 10L) * 1000L

    fun librarySig(c: Context): String =
        "${of(c).getString(SORT, "path")}|${of(c).getString(MIN_DURATION, "0")}"

    fun applyTheme(c: Context) {
        val mode = when (of(c).getString(THEME, "system")) {
            "light" -> AppCompatDelegate.MODE_NIGHT_NO
            "dark" -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
        AppCompatDelegate.setDefaultNightMode(mode)
    }
}
