package com.example.pemutarmusik

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer

/**
 * Efek audio dipasang pada sesi audio pemutar (juga dipakai pemain crossfade),
 * sehingga berlaku untuk semua lagu. Nilai disimpan di pengaturan.
 */
object AudioFx {
    const val K_ON = "fx_on"
    const val K_PRESET = "fx_preset"      // -1 = kustom
    const val K_BANDS = "fx_bands"        // milibel, dipisah koma
    const val K_BASS = "fx_bass"          // 0..1000
    const val K_VIRT = "fx_virt"          // 0..1000
    const val K_LOUD = "fx_loud"          // milibel 0..1500

    private var eq: Equalizer? = null
    private var bass: BassBoost? = null
    private var virt: Virtualizer? = null
    private var loud: LoudnessEnhancer? = null

    var bandCount = 0
        private set
    var minLevel = 0
        private set
    var maxLevel = 0
        private set
    var centerHz = IntArray(0)
        private set
    var presets: List<String> = emptyList()
        private set

    val hasEq: Boolean get() = eq != null
    val hasBass: Boolean get() = bass != null
    val hasVirt: Boolean get() = virt != null
    val hasLoud: Boolean get() = loud != null
    val available: Boolean get() = hasEq || hasBass || hasVirt || hasLoud

    fun attach(ctx: Context, session: Int) {
        release()
        try {
            val e = Equalizer(0, session)
            eq = e
            bandCount = e.numberOfBands.toInt()
            val r = e.bandLevelRange
            minLevel = r[0].toInt()
            maxLevel = r[1].toInt()
            centerHz = IntArray(bandCount) { e.getCenterFreq(it.toShort()) / 1000 }
            presets = (0 until e.numberOfPresets.toInt()).map { e.getPresetName(it.toShort()) }
        } catch (_: Throwable) {
            eq = null
        }
        try { bass = BassBoost(0, session) } catch (_: Throwable) { bass = null }
        try { virt = Virtualizer(0, session) } catch (_: Throwable) { virt = null }
        try { loud = LoudnessEnhancer(session) } catch (_: Throwable) { loud = null }
        apply(ctx)
    }

    fun release() {
        try { eq?.release() } catch (_: Throwable) {}
        try { bass?.release() } catch (_: Throwable) {}
        try { virt?.release() } catch (_: Throwable) {}
        try { loud?.release() } catch (_: Throwable) {}
        eq = null
        bass = null
        virt = null
        loud = null
    }

    /** Level pita saat ini (milibel), dari pengaturan. */
    fun levels(ctx: Context): IntArray {
        val raw = Prefs.of(ctx).getString(K_BANDS, "") ?: ""
        val parts = raw.split(',')
        return IntArray(bandCount) { parts.getOrNull(it)?.toIntOrNull() ?: 0 }
    }

    fun apply(ctx: Context) {
        val p = Prefs.of(ctx)
        val on = p.getBoolean(K_ON, false)
        try {
            eq?.let { e ->
                e.setEnabled(on)
                if (on) {
                    val preset = p.getInt(K_PRESET, -1)
                    if (preset in 0 until presets.size) {
                        e.usePreset(preset.toShort())
                    } else {
                        val lv = levels(ctx)
                        for (i in 0 until bandCount) {
                            e.setBandLevel(i.toShort(), lv[i].coerceIn(minLevel, maxLevel).toShort())
                        }
                    }
                }
            }
        } catch (_: Throwable) {}
        try {
            bass?.let { b ->
                val s = p.getInt(K_BASS, 0)
                b.setEnabled(on && s > 0)
                if (s > 0) b.setStrength(s.coerceIn(0, 1000).toShort())
            }
        } catch (_: Throwable) {}
        try {
            virt?.let { v ->
                val s = p.getInt(K_VIRT, 0)
                v.setEnabled(on && s > 0)
                if (s > 0) v.setStrength(s.coerceIn(0, 1000).toShort())
            }
        } catch (_: Throwable) {}
        try {
            loud?.let { l ->
                val g = p.getInt(K_LOUD, 0)
                l.setEnabled(on && g > 0)
                if (g > 0) l.setTargetGain(g)
            }
        } catch (_: Throwable) {}
    }

    /** Pilih preset bawaan perangkat lalu simpan level pitanya. */
    fun selectPreset(ctx: Context, idx: Int) {
        val e = eq ?: return
        try {
            e.usePreset(idx.toShort())
            val lv = IntArray(bandCount) { e.getBandLevel(it.toShort()).toInt() }
            Prefs.of(ctx).edit()
                .putInt(K_PRESET, idx)
                .putString(K_BANDS, lv.joinToString(","))
                .apply()
        } catch (_: Throwable) {}
    }

    /** Ubah satu pita; otomatis menjadi preset "Kustom". */
    fun setBand(ctx: Context, band: Int, level: Int) {
        val lv = levels(ctx)
        if (band !in lv.indices) return
        lv[band] = level
        Prefs.of(ctx).edit()
            .putInt(K_PRESET, -1)
            .putString(K_BANDS, lv.joinToString(","))
            .apply()
        apply(ctx)
    }

    fun resetAll(ctx: Context) {
        Prefs.of(ctx).edit()
            .putInt(K_PRESET, -1)
            .putString(K_BANDS, IntArray(bandCount).joinToString(","))
            .putInt(K_BASS, 0)
            .putInt(K_VIRT, 0)
            .putInt(K_LOUD, 0)
            .apply()
        apply(ctx)
    }
}
