package com.example.pemutarmusik

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.io.File

class MainActivity : AppCompatActivity() {

    private enum class Kind {
        ROOT, ALL, FOLDERS, FOLDER, ALBUMS, ALBUM, ARTISTS, ARTIST,
        PLAYLISTS, PLAYLIST, FAVORITES, QUEUE, SEARCH
    }

    private class Node(val kind: Kind, val title: String, val key: String = "")

    private class Row(
        val title: String,
        val sub: String,
        val spoken: String,
        val trackId: Long = -1L,
        val onLong: (() -> Unit)? = null,
        val onClick: () -> Unit
    )

    private companion object {
        const val HOLD_DELAY_MS = 450L
        const val HOLD_REPEAT_MS = 200L
        const val HOLD_STEP_MS = 5000L
        const val APP_NAME = "Musik Player Novan"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    private var tracks: List<Track> = emptyList()
    private val stack = ArrayList<Node>()
    private var rows: List<Row> = emptyList()
    private var touching = false
    private var playingId = -1L
    private var lastSpoken = ""
    private var lastPct = -1
    private var pendingOpen: android.net.Uri? = null
    private var libSig = ""

    private lateinit var list: ListView
    private lateinit var tvTitle: TextView
    private lateinit var btnBack: Button
    private lateinit var actionRow: LinearLayout
    private lateinit var btnPlayFolder: Button
    private lateinit var btnShufflePlay: Button
    private lateinit var nowTitle: TextView
    private lateinit var nowArtist: TextView
    private lateinit var seek: SeekBar
    private lateinit var tvCur: TextView
    private lateinit var tvDur: TextView
    private lateinit var btnPlay: ImageButton
    private lateinit var btnShuffle: Button
    private lateinit var btnRepeat: Button
    private lateinit var btnRew: Button
    private lateinit var btnFf: Button
    private lateinit var btnFav: Button
    private lateinit var btnMore: Button

    private val adapter = object : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int) = rows[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView
                ?: layoutInflater.inflate(android.R.layout.simple_list_item_2, parent, false)
            val r = rows[position]
            val playing = r.trackId != -1L && r.trackId == playingId
            v.findViewById<TextView>(android.R.id.text1).apply {
                text = r.title
                textSize = 20f
            }
            v.findViewById<TextView>(android.R.id.text2).apply {
                text = if (playing) "${r.sub} · sedang diputar" else r.sub
                textSize = 16f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            }
            v.minimumHeight = dp(64)
            v.contentDescription = if (playing) "${r.spoken}, sedang diputar" else r.spoken
            return v
        }
    }

    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = goBack()
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { loadTracks() }

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            updateUi()
            if (stack.lastOrNull()?.kind == Kind.QUEUE &&
                (events.contains(Player.EVENT_TIMELINE_CHANGED) ||
                    events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION))
            ) {
                refreshList(true)
            }
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            val c = controller
            if (c != null && !touching) {
                val d = c.duration
                val pos = c.currentPosition
                if (d != C.TIME_UNSET && d > 0) {
                    seek.max = d.toInt()
                    seek.progress = pos.toInt()
                }
                tvCur.text = fmt(pos)
                tvDur.text = if (d == C.TIME_UNSET) "0:00" else fmt(d)
                if (d != C.TIME_UNSET && d > 0) {
                    // diperbarui tiap 5 detik agar pembaca layar tidak cerewet
                    val sp = "${percentOf(pos, d)} persen, ${spoken(pos / 5000 * 5000)} dari ${spoken(d)}"
                    if (sp != lastSpoken) {
                        lastSpoken = sp
                        ViewCompat.setStateDescription(seek, sp)
                    }
                }
            }
            handler.postDelayed(this, 500)
        }
    }

    // ---------------------------------------------------------------- siklus hidup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        list = findViewById(R.id.list)
        tvTitle = findViewById(R.id.tvTitle)
        btnBack = findViewById(R.id.btnBack)
        actionRow = findViewById(R.id.actionRow)
        btnPlayFolder = findViewById(R.id.btnPlayFolder)
        btnShufflePlay = findViewById(R.id.btnShufflePlay)
        nowTitle = findViewById(R.id.nowTitle)
        nowArtist = findViewById(R.id.nowArtist)
        seek = findViewById(R.id.seek)
        tvCur = findViewById(R.id.tvCur)
        tvDur = findViewById(R.id.tvDur)
        btnPlay = findViewById(R.id.btnPlay)
        btnShuffle = findViewById(R.id.btnShuffle)
        btnRepeat = findViewById(R.id.btnRepeat)
        btnRew = findViewById(R.id.btnRew)
        btnFf = findViewById(R.id.btnFf)
        btnFav = findViewById(R.id.btnFav)
        btnMore = findViewById(R.id.btnMore)
        ViewCompat.setAccessibilityHeading(tvTitle, true)

        stack.add(Node(Kind.ROOT, APP_NAME))
        list.adapter = adapter
        onBackPressedDispatcher.addCallback(this, backCallback)

        list.setOnItemClickListener { _, _, pos, _ -> rows.getOrNull(pos)?.onClick?.invoke() }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            val l = rows.getOrNull(pos)?.onLong
            if (l != null) {
                l()
                true
            } else false
        }
        btnBack.setOnClickListener { goBack() }
        btnPlayFolder.setOnClickListener {
            val t = currentTracks()
            if (t.isNotEmpty()) play(t, 0)
        }
        btnShufflePlay.setOnClickListener {
            val t = currentTracks()
            if (t.isNotEmpty()) {
                controller?.shuffleModeEnabled = true
                play(t, t.indices.random())
                toast("Acak aktif")
            }
        }

        btnPlay.setOnClickListener {
            val c = controller ?: return@setOnClickListener
            if (c.isPlaying) c.pause() else {
                if (c.mediaItemCount == 0) return@setOnClickListener
                if (c.playbackState == Player.STATE_ENDED) c.seekToDefaultPosition()
                c.play()
            }
        }

        // Gaya Jet Audio:
        //  - tekan singkat "sebelumnya": jika lagu sudah berjalan > 3 detik, ulang dari awal;
        //    jika belum, pindah ke lagu sebelumnya
        //  - tekan singkat "berikutnya": lagu berikutnya (menyatu dengan crossfade)
        //  - tahan salah satu tombol: mundur/maju cepat dalam lagu
        holdSeek(findViewById(R.id.btnPrev), -1) { controller?.seekToPrevious() }
        holdSeek(findViewById(R.id.btnNext), +1) { controller?.seekToNext() }

        // Tombol eksplisit (ramah pembaca layar, tanpa perlu gestur tahan)
        btnRew.setOnClickListener { seekBy(-Prefs.seekStepMs(this)) }
        btnFf.setOnClickListener { seekBy(Prefs.seekStepMs(this)) }

        btnShuffle.setOnClickListener { v ->
            controller?.let {
                val on = !it.shuffleModeEnabled
                it.shuffleModeEnabled = on
                v.announceForAccessibility(if (on) "Acak aktif" else "Acak mati")
            }
        }
        btnRepeat.setOnClickListener { v ->
            controller?.let {
                val next = when (it.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
                it.repeatMode = next
                v.announceForAccessibility(
                    when (next) {
                        Player.REPEAT_MODE_ALL -> "Ulang semua lagu"
                        Player.REPEAT_MODE_ONE -> "Ulang satu lagu"
                        else -> "Ulang mati"
                    }
                )
            }
        }
        btnFav.setOnClickListener {
            val id = controller?.currentMediaItem?.mediaId?.toLongOrNull() ?: return@setOnClickListener
            val now = Playlists.toggleFav(this, id)
            toast(if (now) "Ditambahkan ke favorit" else "Dihapus dari favorit")
            updateUi()
            refreshList(true)
        }
        btnMore.setOnClickListener { showMore() }

        // Penggeser posisi: bisa disentuh/diseret, dan bisa digerakkan pembaca layar
        // (usap atas/bawah atau tombol volume saat TalkBack memfokuskan penggeser).
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                tvCur.text = fmt(p.toLong())
                if (!touching) controller?.seekTo(p.toLong()) // papan tombol / aksesibilitas
                else {
                    // Saat ditekan-tahan lalu digeser: sebutkan persen posisi lagu
                    val pct = percentOf(p.toLong(), s.max.toLong())
                    if (pct != lastPct) {
                        lastPct = pct
                        s.announceForAccessibility("$pct persen")
                    }
                }
            }

            override fun onStartTrackingTouch(s: SeekBar) {
                touching = true
                lastPct = -1
            }

            override fun onStopTrackingTouch(s: SeekBar) {
                controller?.seekTo(s.progress.toLong())
                touching = false
                lastSpoken = ""
                s.announceForAccessibility("${percentOf(s.progress.toLong(), s.max.toLong())} persen")
            }
        })
        ViewCompat.setAccessibilityDelegate(seek, object : AccessibilityDelegateCompat() {
            override fun performAccessibilityAction(host: View, action: Int, args: Bundle?): Boolean {
                return when (action) {
                    AccessibilityNodeInfo.ACTION_SCROLL_FORWARD -> {
                        seekBy(Prefs.seekStepMs(this@MainActivity), true)
                        true
                    }
                    AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD -> {
                        seekBy(-Prefs.seekStepMs(this@MainActivity), true)
                        true
                    }
                    else -> super.performAccessibilityAction(host, action, args)
                }
            }
        })

        libSig = Prefs.librarySig(this)
        ensurePermission()
        refreshList()
        handleViewIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleViewIntent(intent)
    }

    /** File audio dibuka dari file manager / aplikasi lain: putar langsung di sini. */
    private fun handleViewIntent(i: Intent?) {
        if (i == null || i.action != Intent.ACTION_VIEW) return
        val uri = i.data ?: return
        i.action = Intent.ACTION_MAIN // jangan putar ulang saat Activity dibuat ulang
        pendingOpen = uri
        playPendingOpen()
    }

    private fun playPendingOpen() {
        val uri = pendingOpen ?: return
        val c = controller ?: return
        pendingOpen = null
        c.setMediaItem(Util.externalItem(this, uri), 0L)
        c.prepare()
        c.play()
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            try {
                controller = f.get().also { it.addListener(listener) }
                playPendingOpen()
                updateUi()
                refreshList(true)
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(this))
        handler.post(ticker)
    }

    override fun onResume() {
        super.onResume()
        if (Prefs.librarySig(this) != libSig) {
            libSig = Prefs.librarySig(this)
            loadTracks()
        }
        updateUi()
        refreshList(true)
    }

    override fun onStop() {
        handler.removeCallbacks(ticker)
        controller?.removeListener(listener)
        controller = null
        future?.let { MediaController.releaseFuture(it) }
        future = null
        super.onStop()
    }

    // ---------------------------------------------------------------- izin & data

    private fun audioPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasAudioPermission() =
        checkSelfPermission(audioPermission()) == PackageManager.PERMISSION_GRANTED

    private fun ensurePermission() {
        val wanted = mutableListOf(audioPermission())
        if (Build.VERSION.SDK_INT >= 33) wanted += Manifest.permission.POST_NOTIFICATIONS
        val missing = wanted.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (hasAudioPermission()) loadTracks()
        if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
    }

    private fun loadTracks() {
        if (!hasAudioPermission()) return
        Thread {
            val result = try {
                Library.load(this)
            } catch (_: Exception) {
                emptyList()
            }
            runOnUiThread {
                tracks = result
                refreshList(true)
            }
        }.start()
    }

    // ---------------------------------------------------------------- daftar

    private fun isTrackNode(k: Kind) = k == Kind.ALL || k == Kind.FOLDER || k == Kind.ALBUM ||
        k == Kind.ARTIST || k == Kind.PLAYLIST || k == Kind.FAVORITES || k == Kind.SEARCH

    private fun byIds(ids: List<Long>): List<Track> {
        val m = tracks.associateBy { it.id }
        return ids.mapNotNull { m[it] }
    }

    private fun nodeTracks(n: Node): List<Track> = when (n.kind) {
        Kind.ALL -> tracks
        Kind.FOLDER -> tracks.filter { it.folder == n.key }
        Kind.ALBUM -> tracks.filter { it.album == n.key }
        Kind.ARTIST -> tracks.filter { it.artist == n.key }
        Kind.PLAYLIST -> byIds(Playlists.ids(this, n.key))
        Kind.FAVORITES -> byIds(Playlists.ids(this, Playlists.FAV))
        Kind.SEARCH -> {
            val q = n.key.lowercase()
            tracks.filter {
                it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) ||
                    it.album.lowercase().contains(q)
            }
        }
        else -> emptyList()
    }

    private fun currentTracks(): List<Track> = nodeTracks(stack.last())

    private fun refreshList(keepScroll: Boolean = false) {
        if (stack.isEmpty()) return
        val node = stack.last()
        val first = list.firstVisiblePosition
        tvTitle.text = if (node.kind == Kind.ROOT) APP_NAME else node.title
        btnBack.visibility = if (stack.size > 1) View.VISIBLE else View.GONE
        backCallback.isEnabled = stack.size > 1
        actionRow.visibility =
            if (isTrackNode(node.kind) && nodeTracks(node).isNotEmpty()) View.VISIBLE else View.GONE
        rows = buildRows(node)
        adapter.notifyDataSetChanged()
        list.setSelection(if (keepScroll) first else 0)
    }

    private fun push(n: Node) {
        stack.add(n)
        refreshList()
        list.announceForAccessibility("${n.title}, ${rows.size} item")
    }

    private fun goBack() {
        if (stack.size <= 1) return
        stack.removeAt(stack.size - 1)
        refreshList()
        list.announceForAccessibility(
            if (stack.last().kind == Kind.ROOT) "Menu utama" else stack.last().title
        )
    }

    private fun cat(title: String, sub: String, go: () -> Unit) =
        Row(title, sub, "$title, $sub", onClick = go)

    private fun buildRows(node: Node): List<Row> = when (node.kind) {
        Kind.ROOT -> rootRows()
        Kind.FOLDERS -> tracks.groupBy { it.folder }.toList().sortedBy { it.first.lowercase() }
            .map { (path, l) ->
                val name = File(path).name.ifEmpty { path }
                Row(name, "${l.size} lagu · $path", "Folder $name, ${l.size} lagu",
                    onClick = { push(Node(Kind.FOLDER, name, path)) })
            }
        Kind.ALBUMS -> tracks.groupBy { it.album }.toList().sortedBy { it.first.lowercase() }
            .map { (album, l) ->
                val name = album.ifBlank { "Tanpa album" }
                val artist = l.map { it.artist }.filter { it.isNotEmpty() }.distinct().take(2).joinToString(", ")
                val sub = if (artist.isEmpty()) "${l.size} lagu" else "${l.size} lagu · $artist"
                Row(name, sub, "Album $name, $sub", onClick = { push(Node(Kind.ALBUM, name, album)) })
            }
        Kind.ARTISTS -> tracks.groupBy { it.artist }.toList().sortedBy { it.first.lowercase() }
            .map { (artist, l) ->
                val name = artist.ifBlank { "Tanpa artis" }
                Row(name, "${l.size} lagu", "Artis $name, ${l.size} lagu",
                    onClick = { push(Node(Kind.ARTIST, name, artist)) })
            }
        Kind.PLAYLISTS -> playlistRows()
        Kind.QUEUE -> queueRows()
        else -> trackRows(node)
    }

    private fun rootRows(): List<Row> {
        val out = ArrayList<Row>()
        if (tracks.isEmpty()) {
            out += Row(
                "Belum ada lagu",
                "Pastikan izin akses musik sudah diberikan. Ketuk untuk meminta izin.",
                "Belum ada lagu. Pastikan izin akses musik sudah diberikan. Ketuk dua kali untuk meminta izin",
                onClick = { ensurePermission() }
            )
        }
        val folders = tracks.map { it.folder }.distinct().size
        val albums = tracks.map { it.album }.distinct().size
        val artists = tracks.map { it.artist }.distinct().size
        val favs = Playlists.ids(this, Playlists.FAV).size
        out += cat("Semua lagu", "${tracks.size} lagu") { push(Node(Kind.ALL, "Semua lagu")) }
        out += cat("Folder", "$folders folder") { push(Node(Kind.FOLDERS, "Folder")) }
        out += cat("Album", "$albums album") { push(Node(Kind.ALBUMS, "Album")) }
        out += cat("Artis", "$artists artis") { push(Node(Kind.ARTISTS, "Artis")) }
        out += cat("Daftar putar", "${Playlists.names(this).size} daftar") {
            push(Node(Kind.PLAYLISTS, "Daftar putar"))
        }
        out += cat("Favorit", "$favs lagu") { push(Node(Kind.FAVORITES, "Favorit")) }
        out += cat("Antrean saat ini", "${controller?.mediaItemCount ?: 0} lagu") {
            push(Node(Kind.QUEUE, "Antrean saat ini"))
        }
        out += cat("Cari lagu", "Cari berdasarkan judul, artis, atau album") { promptSearch() }
        out += cat("Pengaturan", "Perpindahan lagu, tampilan, dan lainnya") {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        return out
    }

    private fun trackSub(t: Track): String = when {
        t.artist.isNotEmpty() && t.album.isNotEmpty() -> "${t.artist} · ${t.album}"
        t.artist.isNotEmpty() -> t.artist
        else -> t.album
    }

    private fun trackRows(node: Node): List<Row> {
        val items = nodeTracks(node)
        if (items.isEmpty()) {
            val msg = when (node.kind) {
                Kind.FAVORITES -> "Belum ada lagu favorit. Tekan lama sebuah lagu untuk menambahkannya."
                Kind.PLAYLIST -> "Daftar putar ini masih kosong. Tekan lama sebuah lagu untuk menambahkannya."
                Kind.SEARCH -> "Tidak ada lagu yang cocok."
                else -> "Tidak ada lagu."
            }
            return listOf(Row("Kosong", msg, "Kosong. $msg", onClick = {}))
        }
        val plName = if (node.kind == Kind.PLAYLIST) node.key else null
        return items.mapIndexed { i, t ->
            Row(
                t.title, trackSub(t),
                if (t.artist.isEmpty()) t.title else "${t.title}, ${t.artist}",
                trackId = t.id,
                onLong = { trackMenu(t, plName) },
                onClick = { play(items, i) }
            )
        }
    }

    private fun playlistRows(): List<Row> {
        val out = ArrayList<Row>()
        out += cat("Buat daftar putar baru", "Ketuk untuk membuat") {
            promptText("Nama daftar putar baru", "", "Buat") { n ->
                if (Playlists.create(this, n)) {
                    toast("Daftar putar $n dibuat")
                    refreshList(true)
                } else toast("Nama tidak valid atau sudah ada")
            }
        }
        for (name in Playlists.names(this)) {
            val n = Playlists.ids(this, name).size
            out += Row(name, "$n lagu", "Daftar putar $name, $n lagu",
                onLong = { playlistMenu(name) },
                onClick = { push(Node(Kind.PLAYLIST, name, name)) })
        }
        return out
    }

    private fun queueRows(): List<Row> {
        val c = controller
        if (c == null || c.mediaItemCount == 0) {
            return listOf(Row("Antrean kosong", "Pilih lagu untuk mulai memutar", "Antrean kosong", onClick = {}))
        }
        val cur = c.currentMediaItemIndex
        return (0 until c.mediaItemCount).map { i ->
            val mi = c.getMediaItemAt(i)
            val title = mi.mediaMetadata.title?.toString() ?: "?"
            val artist = mi.mediaMetadata.artist?.toString() ?: ""
            Row(
                "${i + 1}. $title", artist,
                (if (artist.isEmpty()) title else "$title, $artist") +
                    if (i == cur) ", sedang diputar" else "",
                trackId = mi.mediaId.toLongOrNull() ?: -1L,
                onLong = { queueMenu(i) },
                onClick = {
                    c.seekToDefaultPosition(i)
                    c.play()
                }
            )
        }
    }

    // ---------------------------------------------------------------- menu & dialog

    private fun trackMenu(t: Track, playlist: String?) {
        val fav = Playlists.isFav(this, t.id)
        val labels = ArrayList<String>()
        labels += "Putar berikutnya"
        labels += "Tambah ke antrean"
        labels += "Tambah ke daftar putar"
        labels += if (fav) "Hapus dari favorit" else "Tambah ke favorit"
        labels += "Info lagu"
        labels += "Bagikan lagu"
        if (playlist != null) labels += "Hapus dari daftar putar ini"
        AlertDialog.Builder(this)
            .setTitle(t.title)
            .setItems(labels.toTypedArray()) { _, which ->
                when (labels[which]) {
                    "Putar berikutnya" -> enqueue(t, true)
                    "Tambah ke antrean" -> enqueue(t, false)
                    "Tambah ke daftar putar" -> addToPlaylist(t)
                    "Tambah ke favorit", "Hapus dari favorit" -> {
                        val now = Playlists.toggleFav(this, t.id)
                        toast(if (now) "Ditambahkan ke favorit" else "Dihapus dari favorit")
                        updateUi()
                        refreshList(true)
                    }
                    "Info lagu" -> showInfo(t)
                    "Bagikan lagu" -> share(t)
                    "Hapus dari daftar putar ini" -> {
                        Playlists.remove(this, playlist ?: "", t.id)
                        toast("Dihapus dari daftar putar")
                        refreshList(true)
                    }
                }
            }
            .show()
    }

    private fun enqueue(t: Track, next: Boolean) {
        val c = controller
        if (c == null || c.mediaItemCount == 0) {
            play(listOf(t), 0)
            return
        }
        if (next) {
            c.addMediaItem(c.currentMediaItemIndex + 1, t.toMediaItem())
            toast("Akan diputar berikutnya")
        } else {
            c.addMediaItem(t.toMediaItem())
            toast("Ditambahkan ke antrean")
        }
    }

    private fun addToPlaylist(t: Track) {
        val names = Playlists.names(this)
        val labels = (names + "Daftar putar baru...").toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Tambah ke daftar putar")
            .setItems(labels) { _, w ->
                if (w < names.size) {
                    Playlists.add(this, names[w], listOf(t.id))
                    toast("Ditambahkan ke ${names[w]}")
                } else {
                    promptText("Nama daftar putar baru", "", "Buat") { n ->
                        if (Playlists.create(this, n)) {
                            Playlists.add(this, n, listOf(t.id))
                            toast("Ditambahkan ke $n")
                        } else toast("Nama tidak valid atau sudah ada")
                    }
                }
            }
            .show()
    }

    private fun showInfo(t: Track) {
        val msg = "Judul: ${t.title}\n" +
            "Artis: ${t.artist.ifEmpty { "-" }}\n" +
            "Album: ${t.album.ifEmpty { "-" }}\n" +
            "Durasi: ${fmt(t.duration)}\n" +
            "Lokasi: ${t.path}"
        AlertDialog.Builder(this).setTitle("Info lagu").setMessage(msg)
            .setPositiveButton("Tutup", null).show()
    }

    private fun share(t: Track) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "audio/*"
            putExtra(Intent.EXTRA_STREAM, t.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(Intent.createChooser(i, "Bagikan lagu"))
        } catch (_: Exception) {
            toast("Tidak ada aplikasi untuk berbagi")
        }
    }

    private fun playlistMenu(name: String) {
        val labels = arrayOf("Putar", "Ganti nama", "Hapus daftar putar")
        AlertDialog.Builder(this).setTitle(name).setItems(labels) { _, w ->
            when (w) {
                0 -> {
                    val l = byIds(Playlists.ids(this, name))
                    if (l.isEmpty()) toast("Daftar putar masih kosong") else play(l, 0)
                }
                1 -> promptText("Nama baru", name, "Simpan") { n ->
                    if (Playlists.rename(this, name, n)) refreshList(true)
                    else toast("Nama tidak valid atau sudah ada")
                }
                else -> AlertDialog.Builder(this)
                    .setTitle("Hapus daftar putar $name?")
                    .setPositiveButton("Hapus") { _, _ ->
                        Playlists.delete(this, name)
                        toast("Daftar putar dihapus")
                        refreshList(true)
                    }
                    .setNegativeButton("Batal", null).show()
            }
        }.show()
    }

    private fun queueMenu(i: Int) {
        val c = controller ?: return
        val labels = arrayOf("Putar", "Hapus dari antrean", "Pindahkan ke atas", "Pindahkan ke bawah")
        AlertDialog.Builder(this).setTitle("Antrean nomor ${i + 1}").setItems(labels) { _, w ->
            when (w) {
                0 -> {
                    c.seekToDefaultPosition(i)
                    c.play()
                }
                1 -> c.removeMediaItem(i)
                2 -> if (i > 0) c.moveMediaItem(i, i - 1)
                else -> if (i < c.mediaItemCount - 1) c.moveMediaItem(i, i + 1)
            }
        }.show()
    }

    private fun promptSearch() {
        promptText("Cari lagu", "", "Cari") { q ->
            if (q.isNotEmpty()) push(Node(Kind.SEARCH, "Hasil pencarian: $q", q))
        }
    }

    private fun promptText(title: String, initial: String, ok: String, onDone: (String) -> Unit) {
        val et = EditText(this).apply {
            setText(initial)
            setSelection(text.length)
            setSingleLine()
            hint = title
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(et)
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton(ok) { _, _ -> onDone(et.text.toString().trim()) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showMore() {
        val svc = PlaybackService.instance
        val sleepInfo = when {
            svc == null -> ""
            svc.isSleepAfterTrack() -> " (setelah lagu ini)"
            svc.sleepRemainingMs() > 0 -> " (sisa ${svc.sleepRemainingMs() / 60000 + 1} menit)"
            else -> ""
        }
        val speed = controller?.playbackParameters?.speed ?: 1f
        val labels = arrayOf(
            "Cari lagu",
            "Antrean saat ini",
            "Timer tidur$sleepInfo",
            "Kecepatan putar: ${speedLabel(speed)}",
            "Ulang A-B",
            "Equalizer dan efek suara",
            "Segarkan daftar lagu",
            "Pengaturan",
            "Tentang"
        )
        AlertDialog.Builder(this).setTitle("Menu").setItems(labels) { _, w ->
            when (w) {
                0 -> promptSearch()
                1 -> push(Node(Kind.QUEUE, "Antrean saat ini"))
                2 -> showSleepTimer()
                3 -> showSpeed()
                4 -> showAB()
                5 -> startActivity(Intent(this, EqualizerActivity::class.java))
                6 -> {
                    loadTracks()
                    toast("Menyegarkan daftar lagu")
                }
                7 -> startActivity(Intent(this, SettingsActivity::class.java))
                else -> AlertDialog.Builder(this)
                    .setTitle(APP_NAME)
                    .setMessage(
                        "Versi 2.0\n\nPemutar musik sederhana dengan perpindahan lagu yang menyatu " +
                            "(gapless dan crossfade), equalizer, timer tidur, ulang A-B, daftar putar, " +
                            "dan tampilan yang ramah pembaca layar."
                    )
                    .setPositiveButton("Tutup", null).show()
            }
        }.show()
    }

    private fun showSleepTimer() {
        val svc = PlaybackService.instance
        if (svc == null) {
            toast("Pemutar belum siap")
            return
        }
        val labels = arrayOf(
            "Matikan timer", "5 menit", "10 menit", "15 menit", "30 menit",
            "45 menit", "60 menit", "90 menit", "Setelah lagu ini selesai"
        )
        val mins = intArrayOf(0, 5, 10, 15, 30, 45, 60, 90)
        AlertDialog.Builder(this).setTitle("Timer tidur").setItems(labels) { _, w ->
            when {
                w == 0 -> {
                    svc.cancelSleep()
                    toast("Timer tidur dimatikan")
                }
                w == 8 -> {
                    svc.sleepAfterTrack()
                    toast("Pemutaran berhenti setelah lagu ini selesai")
                }
                else -> {
                    svc.startSleep(mins[w])
                    toast("Pemutaran berhenti dalam ${mins[w]} menit")
                }
            }
        }.show()
    }

    private fun showSpeed() {
        val c = controller
        if (c == null) {
            toast("Pemutar belum siap")
            return
        }
        val values = floatArrayOf(0.5f, 0.75f, 0.9f, 1f, 1.1f, 1.25f, 1.5f, 1.75f, 2f)
        val labels = values.map { speedLabel(it) + if (it == 1f) " (normal)" else "" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Kecepatan putar").setItems(labels) { _, w ->
            c.setPlaybackSpeed(values[w])
            toast("Kecepatan ${speedLabel(values[w])}")
        }.show()
    }

    private fun showAB() {
        val svc = PlaybackService.instance
        if (svc == null) {
            toast("Pemutar belum siap")
            return
        }
        val status = when {
            svc.abA >= 0 && svc.abB > 0 -> "aktif, ${fmt(svc.abA)} sampai ${fmt(svc.abB)}"
            svc.abA >= 0 -> "titik A di ${fmt(svc.abA)}"
            else -> "belum diatur"
        }
        val labels = arrayOf(
            "Tandai titik A di posisi sekarang",
            "Tandai titik B dan mulai mengulang",
            "Hapus ulang A-B"
        )
        AlertDialog.Builder(this).setTitle("Ulang A-B: $status").setItems(labels) { _, w ->
            when (w) {
                0 -> toast("Titik A ditandai di ${fmt(svc.markA())}")
                1 -> if (svc.markB()) toast("Ulang A-B aktif")
                else toast("Tandai titik A dulu, lalu pilih titik B setelahnya")
                else -> {
                    svc.clearAB()
                    toast("Ulang A-B dihapus")
                }
            }
        }.show()
    }

    // ---------------------------------------------------------------- pemutaran

    private fun play(items: List<Track>, start: Int) {
        val c = controller
        if (c == null) {
            toast("Pemutar belum siap, coba lagi sebentar")
            return
        }
        c.setMediaItems(items.map { it.toMediaItem() }, start, 0L)
        c.prepare()
        c.play()
    }

    private fun seekBy(delta: Long, announce: Boolean = false) {
        val c = controller ?: return
        val d = c.duration
        if (d == C.TIME_UNSET || d <= 0) return
        val np = (c.currentPosition + delta).coerceIn(0L, maxOf(0L, d - 500))
        c.seekTo(np)
        seek.progress = np.toInt()
        tvCur.text = fmt(np)
        val sp = "${percentOf(np, d)} persen, ${spoken(np)} dari ${spoken(d)}"
        lastSpoken = sp
        ViewCompat.setStateDescription(seek, sp)
        if (announce) seek.announceForAccessibility("${percentOf(np, d)} persen, ${spoken(np)}")
    }

    private fun holdSeek(btn: View, dir: Int, onClick: () -> Unit) {
        var held = false
        btn.setOnClickListener { onClick() } // dipakai TalkBack (ketuk dua kali)
        val repeat = object : Runnable {
            override fun run() {
                held = true
                val c = controller ?: return
                val d = c.duration
                if (d != C.TIME_UNSET && d > 0) {
                    c.seekTo((c.currentPosition + dir * HOLD_STEP_MS).coerceIn(0L, maxOf(0L, d - 500)))
                }
                handler.postDelayed(this, HOLD_REPEAT_MS)
            }
        }
        btn.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    held = false
                    v.isPressed = true
                    handler.postDelayed(repeat, HOLD_DELAY_MS)
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(repeat)
                    v.isPressed = false
                    if (!held) v.performClick()
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(repeat)
                    v.isPressed = false
                }
            }
            true
        }
    }

    private fun updateUi() {
        val step = (Prefs.seekStepMs(this) / 1000).toInt()
        btnRew.text = "Mundur $step detik"
        btnFf.text = "Maju $step detik"
        ViewCompat.setAccessibilityLiveRegion(
            nowTitle,
            if (Prefs.of(this).getBoolean(Prefs.ANNOUNCE, true))
                ViewCompat.ACCESSIBILITY_LIVE_REGION_POLITE
            else ViewCompat.ACCESSIBILITY_LIVE_REGION_NONE
        )
        val c = controller ?: return
        val title = c.mediaMetadata.title?.toString()
        val artist = c.mediaMetadata.artist?.toString() ?: ""
        nowTitle.text = title ?: "Belum ada lagu diputar"
        nowArtist.text = artist
        nowTitle.contentDescription = when {
            title == null -> "Belum ada lagu diputar"
            artist.isEmpty() -> "Sedang diputar: $title"
            else -> "Sedang diputar: $title, $artist"
        }
        btnPlay.setImageResource(
            if (c.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        )
        btnPlay.contentDescription = if (c.isPlaying) "Jeda" else "Putar"
        btnShuffle.text = if (c.shuffleModeEnabled) "Acak: aktif" else "Acak: mati"
        btnRepeat.text = when (c.repeatMode) {
            Player.REPEAT_MODE_ALL -> "Ulang: semua"
            Player.REPEAT_MODE_ONE -> "Ulang: satu"
            else -> "Ulang: mati"
        }
        val id = c.currentMediaItem?.mediaId?.toLongOrNull()
        btnFav.isEnabled = id != null
        btnFav.text = if (id != null && Playlists.isFav(this, id)) "Hapus dari favorit" else "Tambah ke favorit"
        val pid = id ?: -1L
        if (pid != playingId) {
            playingId = pid
            adapter.notifyDataSetChanged()
        }
    }

    // ---------------------------------------------------------------- pembantu

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun speedLabel(s: Float): String =
        if (s == s.toInt().toFloat()) "${s.toInt()}x" else "${s}x"

    private fun spoken(ms: Long) = Util.spoken(ms)

    private fun fmt(ms: Long) = Util.fmt(ms)

    private fun percentOf(pos: Long, dur: Long) = Util.percent(pos, dur)
}
