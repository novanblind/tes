package com.example.pemutarmusik

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import java.io.File

data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val path: String,
    val duration: Long,
    val added: Long
) {
    val uri: Uri
        get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)

    val folder: String
        get() = File(path).parent ?: ""

    fun toMediaItem(): MediaItem =
        MediaItem.Builder()
            .setMediaId(id.toString())
            .setUri(uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(title)
                    .setArtist(artist.ifEmpty { null })
                    .setAlbumTitle(album.ifEmpty { null })
                    .build()
            )
            .build()
}

object Library {

    /** Memuat semua lagu sesuai pengaturan urutan dan durasi minimum. */
    fun load(ctx: Context): List<Track> {
        val p = Prefs.of(ctx)
        val minMs = (p.getString(Prefs.MIN_DURATION, "0")?.toLongOrNull() ?: 0L) * 1000L
        val sort = p.getString(Prefs.SORT, "path") ?: "path"

        val out = ArrayList<Track>()
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED
        )
        val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= ?"
        try {
            ctx.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, sel,
                arrayOf(minMs.toString()), null
            )?.use { c ->
                while (c.moveToNext()) {
                    val artist = c.getString(2)?.takeIf { it != "<unknown>" } ?: ""
                    val album = c.getString(3)?.takeIf { it != "<unknown>" } ?: ""
                    out += Track(
                        id = c.getLong(0),
                        title = c.getString(1) ?: "?",
                        artist = artist,
                        album = album,
                        albumId = c.getLong(4),
                        path = c.getString(5) ?: "",
                        duration = c.getLong(6),
                        added = c.getLong(7)
                    )
                }
            }
        } catch (_: Exception) {
            return emptyList()
        }

        return when (sort) {
            "title" -> out.sortedBy { it.title.lowercase() }
            "artist" -> out.sortedWith(compareBy({ it.artist.lowercase() }, { it.title.lowercase() }))
            "album" -> out.sortedWith(compareBy({ it.album.lowercase() }, { it.path.lowercase() }))
            "added" -> out.sortedByDescending { it.added }
            else -> out.sortedBy { it.path.lowercase() }
        }
    }
}
